@extends('layouts.app')
@section('content')
@include('incu.pagehead')
@include('incu.aboutus')
@include('incu.patrons') 

@endsection