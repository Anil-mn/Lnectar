@extends('layouts.dey')
@section('content')
@include('incu.pagehead')
@include('incu.pdetails')
 

@endsection