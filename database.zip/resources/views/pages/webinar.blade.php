@extends('layouts.app')
@section('content')
@include('incu.pagehead')
@include('incu.webinars')
 

@endsection