<!-- Inner Page Banner Area Start Here -->
<div class="inner-page-banner-area" style="background-image: url('{{URL::asset('img/banner/04.jpg')}}');">'
    <div class="container">
        <div class="pagination-area">
            <h1>{{$head}}</h1>
            <ul>
                <li><a href="#">Home</a> </li>
                <li></li>
            </ul>
        </div>
    </div>
</div>
<!-- Inner Page Banner Area End Here -->