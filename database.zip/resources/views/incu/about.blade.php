

<!-- About Page 2 Area Start Here -->
<div class="about-page2-area">
    <div class="container">
        <div class="row about-page2-inner">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <h2 class="title-default-left">The Motive</h2>
                <p>NECTAR is organizing a fully online e-conference on Technologies Annexing Reality.
                    Technological annexations have provided our world with new environments and keeps the human horizons to grow.
                    Technology.. it’s everywhere, it’s been growing like human population..'</p>
                <ul>
                    <li><a href="#">Entertainment</a></li>
                    <li><a href="#">Healthcare</a></li>
                    <li><a href="#">Education</a></li>
                    <li><a href="#">Defense and many more</a></li>
                </ul>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                <div class="video-area2 overlay-video bg-common-style video-margin-top" style="background-image: url("img/banner/6.jpg");">
                    <div class="video-content">
                        <a class="play-btn popup-youtube" href="http://www.youtube.com/watch?v=o5JB0ydxibk"><i class="fa fa-play" aria-hidden="true"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- About Page 2 Area End Here -->