<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class papers extends Model
{
  public $id = 'id';
}
