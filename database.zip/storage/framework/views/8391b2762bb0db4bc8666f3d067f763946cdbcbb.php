 
 
 <!-- Courses Page 2 Area Start Here -->
 <div class="courses-page-area2">
    <div class="container" id="inner-isotope">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="isotop-classes-tab isotop-btn">
                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($sec->Section_ID==1): ?>
                    <a href="#" data-filter=".<?php echo e($sec->SubSection); ?>" class="current"><?php echo e($sec->SubSection); ?></a>
                    <?php else: ?>
                    <a href="#" data-filter=".<?php echo e($sec->SubSection); ?>"><?php echo e($sec->SubSection); ?></a>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </div>
            </div>
        </div>
        <div class="row featuredContainer">
            <?php $__currentLoopData = $papers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12 <?php echo e($paper->Section_Name); ?>">
                <div class="courses-box1">
                    <div class="single-item-wrapper">
                        <div class="courses-img-wrapper hvr-bounce-to-bottom">

                            <video width="100%" height="100%" controls autoplay muted controlsList="nodownload">
                                <source src="videos/<?php echo e($paper->Link_ID); ?>" type="video/mp4">
                            </video>    
                        
                        <a href="/paperdetails/<?php echo e($paper->Paper_ID); ?>">Click<i class="fa fa-angle-right" aria-hidden="true"></i></a>
                        
                        </div>
                        <div class="courses-content-wrapper">
                            <h3 class="item-title"><a href="/paperdetails/<?php echo e($paper->Paper_ID); ?>"></a>
                                <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($us->Email_ID == $paper->Email): ?>
                                  <?php else: ?>
                                  <?php echo e(Str::limit($us->Name, 20)); ?>

                                 
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                             
                            </h3>
                        <p class="item-content"><?php echo e(Str::limit($paper->Heading, 30)); ?></p>
                           
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
        </div>
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <ul class="pagination-center">
                
             </ul>
        </div>
        
    </div>
</div>
<!-- Courses Page 2 Area End Here -->