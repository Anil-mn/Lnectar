
<?php $__env->startSection('content'); ?>
   <h1>post</h1>
<?php $__env->stopSection(); ?>