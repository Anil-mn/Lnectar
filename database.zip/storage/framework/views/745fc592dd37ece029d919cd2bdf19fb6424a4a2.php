<!-- Counter Area Start Here -->
<div class="counter-area bg-primary-deep" style="background-image: url('img/banner/04.jpg');">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 counter1-box wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".20s">
                <h2 class="about-counter title-bar-counter" data-num="<?php echo e($CountOfuser); ?>">80</h2>
                <p>webinars</p>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 counter1-box wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".40s">
                <h2 class="about-counter title-bar-counter" data-num="<?php echo e($CountOfpaper); ?>">20</h2>
                <p>papers</p>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 counter1-box wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".60s">
                <h2 class="about-counter title-bar-counter" data-num="<?php echo e($CountOfSection); ?>">56</h2>
                <p>sections</p>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 counter1-box wow fadeInUp" data-wow-duration=".5s" data-wow-delay=".60s">
                <h2 class="about-counter title-bar-counter" data-num="<?php echo e($CountOfevents); ?>">56</h2>
                <p>Events</p>
            </div>
        </div>
    </div>
</div>
<!-- Counter Area End Here -->