<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title><?php echo e(config('app.name', 'Nectar')); ?></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(URL::asset('img/lgo3.png')); ?>">
        <!-- Normalize CSS -->
      
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/app.css')); ?>">
        <!-- Main CSS -->
       <link rel="stylesheet" href="vendor/slider/css/nivo-slider.css" type="text/css" />
      <link rel="stylesheet" href="vendor/slider/css/preview.css" type="text/css" media="screen" />
      <link rel="stylesheet" href="vendor/OwlCarousel/owl.carousel.min.css">
      <link rel="stylesheet" href="vendor/OwlCarousel/owl.theme.default.min.css">
        <script src="<?php echo e(URL::asset('js/modernizr-2.8.3.min.js')); ?>"></script>
        
        </head>