<div class="news-event-area" id="eve">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 news-inner-area" id="#eve">
                <h2 class="title-default-left">Latest News</h2>
                <ul class="news-wrapper">
                    <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $new): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li >
                        <div class="news-img-holder">
                            <a href="#"><img style="height:120px; width:150px;" src="images/News/<?php echo e($new->News_ID); ?>.jpg" class="img-responsive" alt="news"></a>
                        </div>
                        <div class="news-content-holder">
                            <h3><a href="" ><?php echo e($new ->Headline); ?></a></h3>
                            <div class="post-date"><?php echo e($new ->Date); ?></div>
                            <p><?php echo e($new->Description); ?></p>
                        </div>
                        </li>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                       <div class="news-btn-holder">

                        </div>
                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 event-inner-area" >
                            <h2 class="title-default-left">Upcoming Events</h2>
                                    <ul class="event-wrapper">
                                        <?php $__currentLoopData = $event; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eves): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php 
                                        $timestamp = strtotime($eves->Date);
                                        $date1= date('d', $timestamp);
                                        $month = date('F',$timestamp);
                                        $year = date('Y',$timestamp);
                                        $formattedDate = date('F d, Y', $timestamp);  
                                        
                                         ?>
                                        <li class="wow bounceInUp" data-wow-duration="2s" data-wow-delay=".'.$GLOBALS ['i'].'s">
                                            <div class="event-calender-wrapper">
                                                <div class="event-calender-holder">
                                                    <h3><?php echo e($date1); ?></h3>
                                                <p><?php echo e($month); ?></p>
                                                    <span><?php echo e($year); ?></span>
                                                </div>
                                            </div>
                                            <div class="event-content-holder">
                                                <h3><a href=""><?php echo e($eves->Heading); ?></a></h3>
                                                <p><?php echo e($eves->Description); ?></p>
                                                <ul>
                                                    <li><?php echo e($eves->time); ?></li>
                                                    <li>NCREC , KERALA</li>
                                                </ul>
                                            </div>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <div class="event-btn-holder">
                                           
                                        </div>
                                       </div>
                                       </div>
                                       </div>
                                       </div></div>