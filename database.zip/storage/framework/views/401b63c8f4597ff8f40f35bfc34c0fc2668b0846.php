<?php $__currentLoopData = $paperDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<!-- Courses Page 3 Area Start Here -->
<div class="courses-page-area3">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 col-md-9 col-sm-8 col-xs-12">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <video width="100%" height="400px" controls autoplay  controlsList="nodownload">
                            <source src="<?php echo e(URL::asset('videos/'.$paper->Link_ID.'')); ?>" type="video/mp4">
                        </video>
                        
                        <div class="course-details-inner">
                            <h2 class="title-default-left title-bar-high"><?php echo e($paper->Heading); ?></h2>
                            <p><?php echo e($paper->Description); ?></p>
                            <h3 class="sidebar-title">Details</h3>
                            <ul class="course-feature">
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               <?php $__currentLoopData = $UserDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($user->Name); ?></li>
                                <li><?php echo e($user->Section_Name); ?></li>
                                <li><?php echo e($user->Qualification); ?></li>
                                
                            </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="section-divider"></div>
                        <div class="course-details-inner">
                            <div class="course-details-comments">
                                <h3 class="sidebar-title">Reviews</h3>
                                <?php $__currentLoopData = $commentsDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                
                                <div class="media">
                                    <a href="#" class="pull-left">
                                        <img alt="Comments" src="<?php echo e(URL::asset('img/comment.png')); ?>" style="height:60px;" class="media-object">
                                    </a>
                                    <div class="media-body">
                                        <h3><a href="#"><?php echo e($com->Name); ?></a></h3>
                                        
                                        <p><?php echo e($com->Comment); ?> </p>
                                        <div class="replay-area">
                                          
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                            </div>
                            <div class="leave-comments">
                                <h3 class="sidebar-title">Leave A Comment</h3>
                                <div class="row">
                                    <?php $__currentLoopData = $paperDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paper): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                     
                                   
                                    <div class="contact-form" id="review-form">
                                        <?php echo Form::open(['action'=>'PagesController@store','Methos'=>'POST']); ?>

                                            <fieldset>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <?php echo e(Form::label('Name','Name')); ?>

                                                        <?php echo e(Form::text('Name', '', ['class' => 'form-control', 'placeholder' => 'Name'])); ?>

                                                       
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-6">
                                                    <div class="form-group">
                                                        <?php echo e(Form::label('Email','Email')); ?>

                                                        <?php echo e(Form::email('Email', '', ['class' => 'form-control', 'placeholder' => 'Email'])); ?>

                                                        <?php echo e(Form::hidden('Paper', $paper->Paper_ID)); ?>

                                                        
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <div class="rate-wrapper">
                                                            
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <?php echo e(Form::label('Comment', 'Commnet')); ?>

                                                        <?php echo e(Form::textarea('Comment', '', ['id' => 'article-ckeditor', 'class' => 'textarea form-control', 'placeholder' => 'Body Text'])); ?>

                                                        
                                                        <div class="help-block with-errors"></div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12">
                                                    <div class="form-group">
                                                        <?php echo e(Form::submit('Post Comment', ['class'=>'view-all-accent-btn'])); ?>

                                                        
                                                    </div>
                                                </div>
                                            </fieldset>
                                      <?php echo Form::close(); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12">
                <div class="sidebar">
                    <div class="sidebar-box">
                        
                    </div> 
                  
                    <?php $__currentLoopData = $Related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <?php  $name = $rel->Section_Name;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    <div class="sidebar-box">
                        <div class="sidebar-box-inner">
                            <h3 class="sidebar-title">Related</h3>
                            <div class="sidebar-related-area">
                                <ul>
                                    <?php $__currentLoopData = $Related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($rel->Paper_ID ==$paper->Paper_ID ): ?>

                                    <?php else: ?>
                                    <li>
                                        <div class="related-img">
                                            <a href="/paperdetails/<?php echo e($rel->Paper_ID); ?>"> <video style="width: 100%; height:100%;"  id="iframeId" src="<?php echo e(URL::asset('videos/'.$paper->Link_ID.'')); ?>" frameborder="0" volume="0" allowfullscreen ></video><a>
                                        </div>
                                        <div class="related-content">
                                           
                                            <h4><a href="/paperdetails/<?php echo e($rel->Paper_ID); ?>"><?php echo e(Str::limit($rel->Heading, 20)); ?></a></h4>
                                          
                                        </div>
                                        <?php endif; ?>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                                </ul>
                            </div>
                        </div>
                    </div>
                  
                </div>
            </div>
        </div>
    </div>
</div>


<!-- Courses Page 3 Area End Here -->