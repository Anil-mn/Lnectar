
<?php $__env->startSection('content'); ?>
   <h1>post</h1>
   <?php if(count($sections)>1): ?>
     <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         
          <div>
             <h3><?php echo e($item->Name); ?></h3>
          </div>   
        
         
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


   <?php else: ?> 
      <p>No </p>
   <?php endif; ?>   
<?php $__env->stopSection(); ?>