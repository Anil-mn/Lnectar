<header>
    <div id="header3" class="header3-area">
        <div class="header-top-area">
            <div class="container">
                <div class="top-bar-border">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="header-top-left">
                                <ul>
                                <li><img src="<?php echo e(URL::asset('img/ncerc logo.png')); ?>" style="height:20px;"></i><a  href="https://ncerc.ac.in/">NCERC</a></li>
                                    <li><i class="fa fa-phone" aria-hidden="true"></i><a href="Tel:9656335444"> 9656335444 </a></li>
                                    <li><i class="fa fa-envelope" aria-hidden="true"></i><a href="#">info@nectar2020.com</a></li>
                                    
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                            <div class="header-top-right">
                                <ul>
                                
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-menu-area" id="sticker">
            <div class="container">
                <div class="row">
                    <div class="col-lg-2 col-md-2 col-sm-3">
                         <div class="logo-area">
                                <a href="./"><img class="img-responsive" src=<?php echo e(URL::asset('img/1234.png')); ?> alt="logo"></a>
                            </div>
                    </div>
                    <div class="col-lg-9 col-md-9 col-sm-9">
                    <nav id="desktop-nav">
                    <ul>
                        <li><a href="./">Home</a></li>
                        <li><a href="/webinar">Webinars</a></li>
                        <li><a href="./#sec">Sections</a></li>
                        <li><a href="about">About us</a></li>
                        <li><a href="./#eve">Events</a> </li>
                       
                       
                        
                        
                    </ul>
                </nav>
                    </div>
                    <div class="col-lg-1 col-md-1 hidden-sm">
                        <div class="header-search">
                       
                      
                            <a href="registration.php" class="apply-now-btn">Register Now</a>
                       
                   
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
    <!-- Mobile Menu Area Start -->
    <div class="mobile-menu-area">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mobile-menu">
                        <nav id="dropdown">
                        <ul>
                            <li><a href="./">Home</a></li>
                            <li><a href="/webinar">Webinars</a></li>
                            <li><a href="./#sec">Sections</a></li>
                            <li><a href="about">About us</a></li>
                            <li><a href="./#eve">Events</a> </li>
                           
                    </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Mobile Menu Area End -->
    
    </header>